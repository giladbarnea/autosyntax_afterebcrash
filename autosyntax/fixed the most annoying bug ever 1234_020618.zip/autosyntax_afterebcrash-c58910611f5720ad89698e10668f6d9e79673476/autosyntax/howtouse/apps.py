from django.apps import AppConfig


class HowtouseConfig(AppConfig):
    name = 'howtouse'
