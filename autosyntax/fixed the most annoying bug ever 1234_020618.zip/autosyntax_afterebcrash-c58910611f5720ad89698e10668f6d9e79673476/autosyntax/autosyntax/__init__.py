#
# j=['milk', 'eggs', 'coffee', 'nutella']
# i = {'meaning': 42, 'happy': 'pizza'}
#
# class Dog(Animal):
# 	def __init__(self, fluffy=True):
# 		self.fluffy = fluffy
# 	    super().__init__()

#
# numbers="hi"
# for number in range(len(numbers)):
#
# def is_easy(autosyntax, *args, **kwargs):
# 	"""
#
# 	"""
# 	hi="hi"
# letters = ""
# printed = [print(letter) for letter in letters]
# w='s'
# hi = f'{w} you'
