from gui.controls.key_sequence_edit import KeySequenceEdit
from gui.controls.tabgroup import TabGroup
