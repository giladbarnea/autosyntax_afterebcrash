# from .Operators import Operator
from .class_operator import ClassOperator
from .def_operator import DefOperator
from .dict_operator import DictOperator
from .for_operator import ForOperator
from .listcomp_operator import ListCompOperator
from .print_operator import PrintOperator
from .str_operator import StrOperator
