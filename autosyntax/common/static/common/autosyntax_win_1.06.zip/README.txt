Launch __init__.exe.
The global hotkey is defaulted to Ctrl+E. 
    You can change it by simply pressing another hotkey while the main window is in focus.
Open try_me.txt, set the caret in one of those lines and press the hotkey. You'll get it.
Have fun :)
